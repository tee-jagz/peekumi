"""Build Repo Strata snapshots from a git repository's first-parent history.

Per commit: modules (by file stem), functions and methods with a hash of their
syntax tree, cyclomatic complexity, internal imports as module dependencies,
calls between functions of the same module, and per-function patches.
"""
import ast, difflib, hashlib, json, re, subprocess, sys
from pathlib import PurePosixPath

REPO = sys.argv[1]
OUT = sys.argv[2]
LAYER_OF = {
    'flask_app': 'entry', 'redis_eventconsumer': 'entry', 'bootstrap': 'entry',
    'services': 'app', 'unit_of_work': 'app', 'messagebus': 'app', 'handlers': 'app', 'views': 'app',
    'model': 'domain', 'events': 'domain', 'commands': 'domain',
    'orm': 'adapters', 'repository': 'adapters', 'notifications': 'adapters',
    'redis_eventpublisher': 'adapters', 'email': 'adapters', 'config': 'adapters',
}
SKIP = re.compile(r'(^|/)tests?/|(^|/)test_[^/]*\.py$|conftest\.py$|setup\.py$|__init__\.py$')


def git(*args):
    return subprocess.run(['git', '-C', REPO, *args], capture_output=True, text=True, check=True).stdout


def complexity(node):
    n = 1
    for sub in ast.walk(node):
        if isinstance(sub, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.IfExp, ast.ExceptHandler, ast.Assert)):
            n += 1
        elif isinstance(sub, ast.BoolOp):
            n += len(sub.values) - 1
        elif isinstance(sub, ast.comprehension):
            n += 1 + len(sub.ifs)
    return n


def norm_hash(node):
    return hashlib.sha1(ast.dump(node, annotate_fields=False, include_attributes=False).encode()).hexdigest()[:12]


def entities(tree, src):
    """Top-level functions, class methods as Class.method, and method-less classes."""
    out = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out[node.name] = node
        elif isinstance(node, ast.ClassDef):
            methods = [m for m in node.body if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if methods:
                for m in methods:
                    out[f'{node.name}.{m.name}'] = m
            else:
                out[node.name] = node
    return out


def internal_deps(tree, stems):
    deps = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                last = a.name.split('.')[-1]
                if last in stems:
                    deps.add(last)
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ''
            last = mod.split('.')[-1] if mod else ''
            if last in stems:
                deps.add(last)
            for a in node.names:
                if a.name in stems:
                    deps.add(a.name)
    return deps


def calls_within(ents):
    names = set(ents)
    edges = set()
    for name, node in ents.items():
        cls = name.split('.')[0] if '.' in name else None
        for sub in ast.walk(node):
            if not isinstance(sub, ast.Call):
                continue
            f = sub.func
            target = None
            if isinstance(f, ast.Name) and f.id in names:
                target = f.id
            elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in ('self', 'cls') and cls:
                cand = f'{cls}.{f.attr}'
                if cand in names:
                    target = cand
            if target and target != name:
                edges.add((name, target))
    return sorted(edges)


def snapshot(sha):
    files = [p for p in git('ls-tree', '-r', '--name-only', sha).splitlines() if p.endswith('.py') and not SKIP.search(p)]
    parsed = {}
    for p in files:
        stem = PurePosixPath(p).stem
        if stem not in LAYER_OF:
            continue
        src = git('show', f'{sha}:{p}')
        try:
            tree = ast.parse(src)
        except SyntaxError:
            continue
        parsed[stem] = (p, src, tree)
    stems = set(parsed)
    mods, calls, edges, sources = {}, {}, [], {}
    for stem, (p, src, tree) in parsed.items():
        ents = entities(tree, src)
        mods[stem] = {n: {'crap': complexity(node), 'mut': None, 'h': norm_hash(node)} for n, node in ents.items()}
        sources[stem] = {n: ast.get_source_segment(src, node) or '' for n, node in ents.items()}
        cs = calls_within(ents)
        if cs:
            calls[stem] = [list(e) for e in cs]
        for d in sorted(internal_deps(tree, stems) - {stem}):
            edges.append({'from': stem, 'to': d, 'kind': 'dep'})
    return mods, calls, edges, sources


def patch(old, new):
    lines = list(difflib.unified_diff((old or '').splitlines(), (new or '').splitlines(), lineterm='', n=2))
    body = [l for l in lines if not l.startswith(('---', '+++', '@@'))]
    return body[:80]


def main():
    shas = git('log', '--first-parent', '--reverse', '--format=%H').split()
    commits, snaps, code = [], [], {}
    prev_key, prev_mods, prev_src = None, {}, {}
    version = {}
    for sha in shas:
        mods, calls, edges, sources = snapshot(sha)
        key = json.dumps([{m: {f: v['h'] for f, v in fs.items()} for m, fs in sorted(mods.items())}, edges], sort_keys=True)
        if not mods or key == prev_key:
            continue
        k = len(snaps)
        for m, fs in mods.items():
            for f, v in fs.items():
                old = prev_mods.get(m, {}).get(f)
                if old is None or old['h'] != v['h']:
                    version[(m, f)] = k
                    code[f'{k}:{m}.{f}'] = patch(prev_src.get(m, {}).get(f), sources[m][f])
                v['v'] = version[(m, f)]
        for m, fs in prev_mods.items():
            for f in fs:
                if f not in mods.get(m, {}):
                    code[f'{k}:{m}.{f}'] = patch(prev_src[m][f], '')
        meta = git('show', '-s', '--format=%h%x1f%an%x1f%ad%x1f%s', '--date=format:%d %b %Y', sha).strip().split('\x1f')
        subject = re.sub(r'\s*\[[^\]]+\]\s*$', '', meta[3]).strip()
        commits.append({'sha': meta[0], 'agent': meta[1].split()[0], 'msg': subject[:90], 'when': meta[2]})
        snaps.append({'mods': {m: {f: {'crap': v['crap'], 'mut': None, 'v': v['v']} for f, v in fs.items()} for m, fs in mods.items()},
                      'calls': calls, 'edges': edges})
        prev_key, prev_mods, prev_src = key, mods, sources
    layers_used = {LAYER_OF[m] for s in snaps for m in s['mods']}
    order = {}
    for s in snaps:
        for m in s['mods']:
            order.setdefault(m, len(order))
    modules = {m: {'layer': LAYER_OF[m], 'x': order[m]} for m in order}
    json.dump({'repo': 'cosmicpython/code', 'metric': 'complexity', 'commits': commits, 'snaps': snaps, 'modules': modules, 'code': code},
              open(OUT, 'w'), separators=(',', ':'))
    print(len(shas), 'commits scanned,', len(snaps), 'kept;', len(modules), 'modules;', len(code), 'patches;', sorted(layers_used))


main()
