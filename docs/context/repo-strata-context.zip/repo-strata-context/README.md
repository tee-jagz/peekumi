# Repo Strata: context pack

Everything built so far for Repo Strata, a mobile-first console for reviewing and steering work done by AI coding agents. Read `SPEC.md` first.

## Files

| Path | What it is |
| --- | --- |
| `SPEC.md` | The developer specification: goals, architecture, generator, schema, diff engine, API, viewer, comments and runs, Ask, security, build plan, open questions. |
| `mockup/repo-strata-sample.html` | Clickable mockup on invented sample data (6 agent commits), with seeded comments, runs and the Prepare run flow. The visual and interaction reference. |
| `mockup/repo-strata-cosmicpython.html` | The same viewer on real snapshots of cosmicpython/code (93 commits, 17 modules), data embedded. Shows real history and the layout stress cases. |
| `generator/strata_gen.py` | Prototype snapshot generator. Walks first-parent history, extracts functions and methods with Python `ast`, hashes them, finds internal imports and in-module calls, computes cyclomatic complexity, and stores per-function patches. |
| `data/cosmicpython-snapshots.json` | The generator's output for cosmicpython/code. Useful as a test fixture. |

## Opening the mockups

Open either HTML file in a browser. No build step and no server. Try it at phone width (390 px) in the browser's device toolbar.

- Tap a card to select it; tap it again to open it. Use the back chevron or breadcrumb to go up.
- Switch Time and Diff at the top, Health and Changes at the bottom of the map.
- In the sample mockup, open commit #5, then Domain, then judge, then tap `score()` to see its patch.
- In the cosmicpython viewer, open commit #33 ("email in model"), go into Domain and switch to Changes to see the one real rule break in its history.

The Ask tab calls Claude through the claude.ai artifact runtime (`window.claude.use('sample')`), so it only answers when the page runs inside claude.ai. Comments and runs are stored in the browser's localStorage.

## Running the generator

```bash
git clone https://github.com/cosmicpython/code.git cp
python3 generator/strata_gen.py cp out.json
```

To run it on another repo, edit the `LAYER_OF` mapping at the top of the script (file name to layer) and the `SKIP` pattern. The production version replaces both with the `.strata.yml` config described in the spec.

## Where the mockup code is reusable

The review logic in the HTML files is plain JavaScript and ports directly:

- `repoDef`, `layerDef`, `moduleDef`: layouts per level, stable across commits.
- `fnStatus`, `modStatus`, `layerStatus`, `itemsFor`, `inScope`: the diff engine and change items.
- `renderGraph`, `edgePath`, `arcPath`: the 2D map and connectors.
- `contextText`, `taskText`, `draftBrief`: the Ask context pack, the run task and the brief prompt.

The rendering code is a prototype. Rebuild it cleanly rather than extending it.
